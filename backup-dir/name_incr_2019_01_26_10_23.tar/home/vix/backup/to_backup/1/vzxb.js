nbv
